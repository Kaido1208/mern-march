import {
  BrowserRouter,
  Routes,
  Route,
} from 'react-router-dom';
import Home from './components/Home';
import HomeComponent from './components/HomeComponent';
import './App.css';

function App() {
  return (
    <BrowserRouter>
    <div className="App">
      <Routes>
        <Route element={<Home />} path='/home'></Route>
        <Route element={<HomeComponent />} path='/:word'></Route>
        <Route element={<HomeComponent />} path ='/:word/:color/:bgColor'></Route>
      </Routes>
    </div>
    </BrowserRouter>
  );
}

export default App;
