import React, {useEffect, useState} from 'react';
import axios from 'axios';
import './App.css';

function App() {

  const [pokemonList, setPokemonList] = useState([]);
    useEffect(() => {
      axios.get("https://pokeapi.co/api/v2/pokemon?limit=807")
        .then((response) => {
        console.log(response.data.results);
        setPokemonList(response.data.results);
        })
        .catch((err) => console.log(err));
  }, []);

    return (
      <div className="App">
        <h1>Axios Pokemon Assignment</h1>
        <li>{pokemonList.map((item, index) => (
          <li key={index}>{item.name}</li>
        ))}</li>
      </div>
    );
}
export default App;