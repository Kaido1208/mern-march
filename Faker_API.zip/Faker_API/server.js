//import faker
const faker = require("faker");

//import express
const express = require("express");
const app = express();
const port = 8000;

//function createUser
const createUser = () => ({
    id: faker.datatype.uuid(),
    firstName: faker.name.firstName(),
    lastName: faker.name.lastName(),
    email: faker.internet.email(),
    password: faker.internet.password(),
    phoneNumber: faker.phone.phoneNumber(),
});
console.log(createUser());

//function createCompany
const createCompany = () => ({
    _id: faker.datatype.uuid(),
    name: faker.company.companyName(),
    address: {
        street: faker.address.streetAddress(),
        city: faker.address.cityName(),
        state: faker.address.state(),
        zipcode: faker.address.zipCode(),
        country: faker.address.country(),
    }
});

//returns a new user
app.get("/api/users/new", (req, res) => {
    const newUser = createUser();
    res.json(newUser);
});

//returns a new company
app.get("/api/companies/new", (req, res) => {
    const newCompany = createCompany();
    res.json(newCompany);
});

app.get("/api/user/company", (req, res) => {
    const newUser = createUser();
    const newCompany = createCompany();
    const newUserCompany = {
        user: newUser,
        company: newCompany
    };
    res.json(newUserCompany);
});

app.listen(port, () => console.log(`Listening on port ${port}`));